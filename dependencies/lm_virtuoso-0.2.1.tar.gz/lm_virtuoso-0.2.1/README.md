# lm_virtuoso

This is a package that provides instances of services to the programs.
It helps applications to locate each other on a network.

### Installation
This package is soon to be uploaded to ... 
- If it is uploaded to somewhere like PyPI, do not forget to add it to requirements.txt.
- You can clone the package's github repo into the project, switch into the directory it is placed and run the code 
```python setup.py install```. The package will be installed and ready for usage.

- You can also copy the generated tar.gz file under dist folder of the package repo and paste it inside the "/dependencies" folder. 

### Usage 
- Import ServiceDiscovery class from service_discovery file
  ```
     from lm_virtuoso.service_discovery import ServiceDiscovery
  ```
- Create a ServiceDiscovery object
  - For the debugging case, it needs to be initiated with a dictionary
of service name keys and instance URL values as a list.<br/>
  
  ``` 
     services = {app.config['CODEX_SERVICE_NAME']: [ app.config['CODEX_URL'] ]}
     service_discovery = ServiceDiscovery(cfg.get('PROFILE_NAME'), cfg.get("DEBUG"), **services) 
  ```
  - In other cases, it updates the services itself after the initialization.<br/>

  ```
     service_discovery = ServiceDiscovery(cfg.get('PROFILE_NAME'), cfg.get("DEBUG"))
  ```
- If other classes need to use the features of the package(ex. codex_helper), do not forget to pass
 the instance.
- Services can be requested, added, removed, updated and printed.

### Notes
- If you want to update lm-virtuoso package;
  - Make changes inside the repo of the package
  - Generate a new tar.gz buy running `python3 setup.py sdist`
  - Do not forget to inform other services that are using this package about the update
- In debug mode, it only returns hard-coded URLs. Boto features are not used.
