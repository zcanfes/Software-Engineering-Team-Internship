import random

import boto3
from apscheduler.schedulers.background import BackgroundScheduler


class ServiceDiscoveryError(Exception):
    """Raised when the service not discovered"""
    pass


class ServiceDiscovery(object):
    def __init__(self, profile_name=None, local=False, dev=False, **services):
        
        self.scheduler = BackgroundScheduler()
        self.external_service_discovery = local or dev
        if self.external_service_discovery:
            if not services:
                raise ServiceDiscoveryError("Please provide a dictionary of services.")
            self.services = services
            return
        try:
            if not profile_name:
                self.client = boto3.Session().client("servicediscovery")
            else:
                self.client = boto3.Session(profile_name=str(profile_name)).client(
                    "servicediscovery"
                )
            self.services = {}
            self.timed_update()
        except (KeyboardInterrupt, SystemExit):
            self.scheduler.shutdown()
        except:
            raise ServiceDiscoveryError("Initialization failed. Check parameters: profile_name, debug.")

    def update(self):
        if self.external_service_discovery:
            raise ServiceDiscoveryError("Service is not present. "
                                        "Debug mode returns hardcoded URLs, cannot update the services.")
        elif not self.client:
            raise ServiceDiscoveryError("Service Discovery is trying to update without being initialized.")
        
        service_response = self.client.list_services().get("Services", [])
        self.services = {}
        for service in service_response:
            name = service.get("Name")
            instance_response = self.client.list_instances(
                ServiceId=service.get("Id")
            ).get("Instances", [])
            instances = []
            for instance in instance_response:
                if "AWS_INSTANCE_IPV4" in instance["Attributes"]:
                    ip = str(instance["Attributes"]["AWS_INSTANCE_IPV4"])
                    port = str(instance["Attributes"]["AWS_INSTANCE_PORT"])
                    instances.append("http://{}:{}".format(ip, port))
                elif "AWS_INSTANCE_CNAME" in instance["Attributes"]:
                    address = str(instance["Attributes"]["AWS_INSTANCE_CNAME"])
                    instances.append(address)

            self.services[name] = instances
        print("Discovered services: ", self.services)

    def timed_update(self):
        self.scheduler.add_job(self.update, 'cron', minute='*/30')
        self.scheduler.start()

    def add_service(self, service_name=None, new_instances=None):
        if not service_name or not new_instances:
            raise ServiceDiscoveryError("This method needs two parameters: service_name, new_instances.")

        instances = self.services.get(service_name, [])
        if self.external_service_discovery:
            instances = []
        if isinstance(new_instances, list):
            instances.extend(new_instances)
        else:
            instances.append(new_instances)

        self.services[service_name] = instances

    def get_service(self, service_name):
        instances = self.services.get(service_name, [])

        if not self.services or not instances:
            self.update()
            instances = self.services.get(service_name, [])
            if not instances:
                raise ServiceDiscoveryError("Not discovered service: {}".format(service_name))

        return random.choice(instances)

    def print_services(self):
        for name, instances in self.services.items():
            print("=====  " + name + "  ====")
            for instance in instances:
                print("\t" + instance)


if __name__ == "__main__":
    sd = ServiceDiscovery(debug=True)
    sd.update()
    sd.print_services()
