from lm_virtuoso.logging import Logger

logger = Logger()
