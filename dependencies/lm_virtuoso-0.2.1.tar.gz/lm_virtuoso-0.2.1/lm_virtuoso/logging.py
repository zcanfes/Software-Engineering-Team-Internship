import logging
import sys

from loguru import logger

ACCEPTABLE_LOG_LEVELS = ["TRACE", "DEBUG", "INFO", "SUCCESS", "WARNING", "ERROR", "CRITICAL"]


def get_format(color, service_name):
    time = "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green>"
    # service_name
    level = "<level>{level.icon: <4}{level: <8}</level>" if color else "<level>{level: <8}</level>"
    thread_name = "{thread.name: <8}"
    function = "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan>"
    message = "<level>{message}</level>"
    return f"{time} | {service_name} | {level} | {thread_name} | {function} | {message}"


def set_logging(log_level, color, service_name, destination=sys.stdout):
    if log_level.upper() in ACCEPTABLE_LOG_LEVELS:
        logger.remove()
        logger.add(destination, level=log_level.upper(), colorize=color, backtrace=False, diagnose=False,
                   format=get_format(color, service_name))
        logger.info(f"Log level is successfully set to {log_level.upper()}")
    else:
        logger.remove()
        logger.add(destination, level="ERROR", colorize=color, backtrace=False, diagnose=False,
                   format=get_format(color, service_name))
        logger.error(f"{log_level.upper()} is not a valid log level, log level is set to ERROR")


class InterceptHandler(logging.Handler):
    def emit(self, record):
        # Retrieve context where the logging call occurred, this happens to be in the 6th frame upward
        logger_opt = logger.opt(depth=6, exception=record.exc_info)
        logger_opt.log(logging.getLevelName(record.levelno), record.getMessage())


class Logger:

    def __init__(self):
        self.logger = logger.opt(ansi=True, depth=2)

    def send_logs(self, method, message):
        getattr(self.logger, method)(message)

    def trace(self, message):
        self.send_logs("trace", message)

    def debug(self, message):
        self.send_logs("debug", message)

    def info(self, message):
        self.send_logs("info", message)

    def success(self, message):
        self.send_logs("success", message)

    def warning(self, message):
        self.send_logs("warning", message)

    def error(self, message):
        self.send_logs("error", message)

    def critical(self, message):
        self.send_logs("critical", message)

    def exception(self, message):
        self.send_logs("exception", message)
